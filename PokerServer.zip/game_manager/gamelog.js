exports.showlog = function (logdata, flg = 0) {
    if(flg == 1) {
        console.log(logdata);
    }
}